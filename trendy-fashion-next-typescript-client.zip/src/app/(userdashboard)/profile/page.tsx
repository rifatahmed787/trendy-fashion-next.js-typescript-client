import Profile from "@/components/UserDashboard/Profile/Profile";
import React from "react";

const ProfilePage = () => {
  return (
    <div>
      <Profile />
    </div>
  );
};

export default ProfilePage;
