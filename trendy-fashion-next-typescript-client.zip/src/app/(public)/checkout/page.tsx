import Checkout from "@/components/Shop/CheckOut/Checkout";
import React from "react";

const CheckOutPage = () => {
  return (
    <div>
      <Checkout />
    </div>
  );
};

export default CheckOutPage;
