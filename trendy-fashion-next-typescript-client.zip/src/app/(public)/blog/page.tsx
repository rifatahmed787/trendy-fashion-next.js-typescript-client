import Blog from "@/components/UI/Pages/Blog/Blog/Blog";
import React from "react";

const BlogPost = () => {
  return (
    <div>
      <Blog />
    </div>
  );
};

export default BlogPost;
