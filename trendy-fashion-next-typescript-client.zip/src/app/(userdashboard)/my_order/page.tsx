import MyOrder from "@/components/UserDashboard/My-order/MyOrder";
import React from "react";

const MyOrders = () => {
  return (
    <div>
      <MyOrder />
    </div>
  );
};

export default MyOrders;
