import ProductList from "@/components/Products/ProductList";
import React from "react";

const Products = () => {
  return (
    <div>
      <ProductList />
    </div>
  );
};

export default Products;
