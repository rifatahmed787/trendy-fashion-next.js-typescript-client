import Cart from "@/components/Shop/ShoppingCart/Cart";
import React from "react";

const AddToCart = () => {
  return (
    <div>
      <Cart />
    </div>
  );
};

export default AddToCart;
