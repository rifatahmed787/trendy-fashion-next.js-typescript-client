export type InputType =
  | "text"
  | "number"
  | "checkbox"
  | "radio"
  | "file"
  | "date"
  | "email"
  | "password"
  | "submit";
