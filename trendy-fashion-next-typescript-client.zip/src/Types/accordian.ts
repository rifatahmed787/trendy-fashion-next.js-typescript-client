export interface IAccordian {
  id: number;
  question: string;
  answer: string;
  category: string;
}
